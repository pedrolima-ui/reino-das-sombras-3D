# Reino das Sombras 3D — RPG 4.0 · Final do Eclipse (atualização de desempenho)

**O mesmo jogo 3D, na pasta `sombras-do-reino-3d`.** Jogo para Chrome/Edge com suporte a WebGL, offline, sem biblioteca externa. Os 35 estágios, seis batalhas contra chefes, regiões, loja, almas, equipamentos, drops, checkpoints, céu estrelado, dragões, floresta e músicas foram mantidos.

## Como atualizar

1. Faça uma cópia da pasta atual, por segurança.
2. Extraia o ZIP e copie os arquivos da pasta `sombras-do-reino-3d` para a pasta do jogo, substituindo as versões anteriores.
3. Abra `index.html` no Chrome ou Edge — **não abra o arquivo ZIP sem extrair**.
4. Seu progresso salvo no mesmo navegador e origem normalmente continua disponível. Se você mudar de endereço/pasta, o navegador pode tratar a nova localização como um salvamento diferente.

A pasta contém:

- `index.html`: jogo e todos os códigos/visuais; contém também **uma cópia embutida do filme final**, para que ele possa rodar mesmo se o MP4 externo não for encontrado;
- `epilogo-reino-livre.mp4`: filme de aproximadamente 32 segundos, em H.264/AAC, para reprodução separada;
- `README.md`: este manual.

## Melhorias de desempenho

- Botões **⚙ GRÁFICOS** no menu principal e no menu de pausa: alternam **Leve**, **Equilibrado** e **Detalhado**.
- **Leve** reduz a resolução de desenho e a quantidade de vegetação distante, evitando mexer em caminhos, inimigos, portais ou colisões.
- **Equilibrado** é o padrão na maioria dos computadores; tem vegetação intermediária e resolução controlada.
- **Detalhado** conserva a maior densidade original e pode exigir computador mais potente.
- Cenas estáticas agora liberam cópias desnecessárias de geometria da memória e os efeitos usam buffers GPU reutilizáveis para evitar alocações repetidas.
- A atualização de textos do HUD não é feita em todo quadro; o 3D deixa de consumir tanto processamento quando o menu ou o vídeo está cobrindo a cena.
- Se ainda houver travamentos, escolha **Leve**. A preferência gráfica fica salva neste navegador.

## Conclusão da campanha — spoiler

Na **fase 35**, depois da derrota do Rei das Sombras, ele revela em seu **diálogo final** ser o pai do protagonista. O herói resolve não repetir a tirania da família. Mantivemos o epílogo em vídeo mostrando a criação de um reino livre, a família do protagonista e sua vida até os 100 anos. O texto de encerramento retoma a revelação e deixa uma pista para um possível segundo jogo.

### Se o vídeo não abrir

Após derrotar o último chefe, clique em **VER O FINAL DA HISTÓRIA** e depois em **▶ REPRODUZIR EPÍLOGO** se o navegador bloquear a reprodução automática. O vídeo está **embutido no `index.html`** como plano de reserva, então não depende mais exclusivamente do arquivo MP4. Depois de concluir o jogo, um botão **🎬 REVER O VÍDEO DO FINAL** aparece no menu. Você também pode abrir o MP4 diretamente.

## Controles

- **WASD** mover; **Shift** correr; **Espaço** pulo duplo; **clique esquerdo** atacar;
- **F** esquiva; **Q** especial; **R** poção; **E** interagir; **P** pausa;
- Na disputa pelo machado do Rei das Sombras, pressione **E repetidamente** enquanto durar o desafio;
- O botão **♫ LIGAR MÚSICA** ativa a trilha dark fantasy original criada com síntese no navegador.

## Verificações desta atualização

JavaScript validado com `node --check`. Fluxo de menu, alteração da qualidade, carregamento da floresta, derrota do chefe final, oito falas da revelação, janela do epílogo, vídeo MP4 reproduzido no Chromium e acesso ao replay do final foram testados com **WebGL simulado**. Isso não equivale a um teste de fluidez com a placa de vídeo do jogador; avalie o desempenho e o visual no seu computador.

O projeto **não foi publicado no GitHub** nesta atualização.
